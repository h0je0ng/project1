function increasePoint(n){
 return new Promise((resolve, reject) => { //성공시resolve 실패시reject
    setTimeout(() => {
        const value = n+1;

        if(value==5){
            const error = new Error();
            error.name = "valueIsFiveError";
            reject(error);
            return;
            
        }
        console.log();
        resolve(1)
    }, 1000); 
});
}

//then 내부에 넣은 함수에서 Promise를 리턴하면 then을 여러번 사용 가능
//재귀함수와 비슷해 
increasePoint(0)

    .then( (n) => {
        return increasePoint(n);
    })
    
    .then( (n) => {
        return increasePoint(n);
    })
    
    .then( (n) => {
        return increasePoint(n);
    })
    
    .then( (n) => {
        return increasePoint(n);
    })
    
    .then( (n) => {
        return increasePoint(n);
    })

    .catch((e) => {
        console.error(e);
    })
async function cancelorder(){
    //요청 보낼 url설정
    let url = "/order/"+ orderId + "/cancel";

    //페이지 설정
    let page = /*[[${page}]]*/ "";


    //서버로 보낼 데이터를 생성
    //주문 id만 포함
    let paramData = {
        orderId: orderId
    };
    

    try{ 
        //비동기 작업을 처리 
        //fetch(): 자바스크립트의 내장 APU와  비동기 통신을 이용하여
        //url을 통해 원하는 결과를 받아옴
        const response = await fetch(url,{
            method:'POST',
            headers:{
                'Content-Type': 'application/json',
            },

            body: JSON.stringify(paramData), 
            cache:'no-cache'

        })
     

        //요청이 성공적으로 처리 되었는지 확인
        //Json형식의 본문을 자바스크립트 객체로 변환
        if(response.ok){
            let result = await response.json();

            alert("주문이 취소 되었습니다.");
            location.href = "/orders/" + page;

        } else if(response.status ==401){
            //서버의응답코드가 401이면 로그인 페이지로 이동
            alert("로그인 후 이용하세요");
            location.href = "/members/login"

        } else {
            //서버의 응답을 텍스트 형태로 변환하여 결과를 출력
            let errorText = await response.text();
            alert(errorText);
        }
        
    } catch(error){
        alert(error.message);
    }
    
}
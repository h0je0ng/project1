package com.example.quiz.mapper;

import com.example.quiz.Dto.QuizDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper //매퍼인터페이스라 꼭 붙여줘야해
public interface QuizMapper {

    int addQuiz(QuizDto dto); //이름 같아야해

    List<QuizDto> listAll(); //목록에 담아줄 list사용 + 데이터타입 QuizDto

    QuizDto findQuiz(int id); //퀴즈 한건씩 검색, id는 정수형

    int changeQuiz(QuizDto dto);

    int removeQuiz(int id);

    QuizDto randomQuiz();

    int removeAll();

    Boolean playQuiz(Map map);
}

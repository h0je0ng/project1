package com.example.quiz.controller;

import com.example.quiz.Dto.QuizDto;
import com.example.quiz.QuizApplication;
import com.example.quiz.form.QuizForm;
import com.example.quiz.service.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.relational.core.sql.In;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.management.modelmbean.ModelMBeanOperationInfo;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/quiz")//RequestMapping 언제 동작해야하는지 알려주는 역할
public class QuizController {

    @Autowired
    private QuizService quizService; //quizService다른 클래스라 다시선언 +의존성주입

    @ModelAttribute
    public QuizForm setUpForm() { //이렇게 넣어주면 유효성 검사를 해서 not null인지 확인해
        QuizForm form = new QuizForm();
        form.setAnswer(true);
        return form;
    }

    @GetMapping //GetMapping 언제 동작해야하는지 알려주는 역할
    //전체 퀴즈 목록표시
    public String showList(QuizForm quizForm, Model model) { //폼의 내용을 받아와서 전달해야하니 model필요 이후 모델 어트리뷰트 해

        quizForm.setNewQuiz(true);//신규 등록 상태

        List<QuizDto> list = quizService.listAll();

        model.addAttribute("list", list);
        model.addAttribute("title", "등록 폼");

        return "crud"; //crud.html을 만들어줘
    }

    //redirectAttributes 인터페이스: 리다이렉트를 수행할때 attribute를 전달하기 위해 사용되는 인터페이스
    //addAttribute 와 addFlashAttribute를 사용할수 있음
    @PostMapping("/insert")
    public String insert(@Validated QuizForm quizForm,
                         BindingResult bindingResult,
                         Model model,
                         RedirectAttributes redirectAttributes) {

        //QuizForm 객체에서 정보를 추출해서 QuizDto에 설정
        QuizDto quiz = new QuizDto();
        quiz.setQuestion(quizForm.getQuestion());
        quiz.setAnswer(quizForm.getAnswer());
        quiz.setAuthor(quizForm.getAuthor());

        //에러가 없는지 확인
        if (!bindingResult.hasErrors()) {
            quizService.addQuiz(quiz);
            redirectAttributes.addAttribute("complete", "등록이 완료 되었습니다.");

            return "redirect:/quiz";
        } else {
            return showList(quizForm, model);
        }
    }

    //업데이트
    //주소창에있는 id(숫자)를 받아오는 것
    @GetMapping("/{id}")
    public String showUpdate(QuizForm quizForm,
                             @PathVariable("id") Integer id,
                             Model model) {
        //id에 해당하는 퀴즈를 검색
        QuizDto quiz = quizService.findQuiz(id);

        //퀴즈가 있으면 QuizForm에 채워넣기
        if (!(quiz == null)) {
            quizForm = makeQuizForm(quiz);

        }

        makeUpdateModel(quizForm, model);
        return "crud";

    }

    @PostMapping("/update")
    public String update(@Validated QuizForm quizForm,
                         BindingResult bindingResult,
                         Model model,
                         RedirectAttributes redirectAttributes) {
        //입력받은 내용을 dto형태로 변환하여 저장
        QuizDto quiz = makeQuiz(quizForm);

        //에러가 없으면 변경처리
        if (!bindingResult.hasErrors()) {
            //내용 변경
            quizService.changeQuiz(quiz);
            redirectAttributes.addFlashAttribute(
                    "complete", "변경이 완료 되었습니다");
            //변경된 화면 표시
            return "redirect:/quiz/" + quiz.getId();
        } else {
            //에러가 있으면 변경을 위한 모델 생성
            makeUpdateModel(quizForm, model);
            return "crud";

        }
    }

    //QuizForm에서 QuizDto로 변환
    private QuizDto makeQuiz(QuizForm quizForm) {
        QuizDto quiz = new QuizDto();
        quiz.setId(quizForm.getId());
        quiz.setQuestion(quizForm.getQuestion());
        quiz.setAnswer(quizForm.getAnswer());
        quiz.setAuthor(quizForm.getAuthor());
        return quiz;
    }

    //quizDto를  QuizForm으로 변환하는 메서드
    private QuizForm makeQuizForm(QuizDto quizDto) {
        QuizForm quizForm = new QuizForm();
        quizForm.setId(quizDto.getId());
        quizForm.setQuestion(quizDto.getQuestion());
        quizForm.setAnswer(quizDto.getAnswer());
        quizForm.setAuthor(quizDto.getAuthor());
        quizForm.setNewQuiz(false);
        return quizForm;
    }

    private void makeUpdateModel(QuizForm quizForm, Model model) {
        model.addAttribute("id", quizForm.getId());
        quizForm.setNewQuiz(false);
        model.addAttribute("quizForm", quizForm);
        model.addAttribute("title", "변경 폼");
    }

    //삭제하기
    @PostMapping("/delete")
    public String delete(String id, Model model, RedirectAttributes redirectAttributes) {
        //폼에서 전달받으면 일단 기본으로 스트링으로 설정 되있기 때문에 String 으로 id 받아와
        quizService.removeQuiz(Integer.parseInt(id)); //int로 지정되어있으니 int로 형변환 팔스인트
        redirectAttributes.addFlashAttribute("delcomplete", "삭제가 완료되었습니다. ");
        return "redirect:/quiz";

    }

    @GetMapping("/play")
    public String showQuiz(QuizForm quizForm, Model model) {
        //랜덤으로 퀴즈를 가져오기
        QuizDto playQuiz = quizService.randomQuiz();
        //값이 있는지 확인
        if(!(playQuiz == null)){
            //값이 있으면 가져온 퀴즈를 폼에 출력
            quizForm = makeQuizForm(playQuiz);
        } else {
            //값이 없으면 "등록된 문제가 없습니다."를 화면에 출력
            model.addAttribute("msg","등록된 문제가 없습니다");
            return "play";


        }
        //저장한 퀴즈를 모데렝 저장하여 play로 리턴
        model.addAttribute("quizForm",quizForm);
        return "play";

    }
    @PostMapping("/check")
    public String checkQuiz(QuizForm quizForm, Boolean answer,Model model){
        //map에 id와 answer을 저장
        Map input= new HashMap();
        input.put("id",quizForm.getId());
        input.put("answer",answer);

        System.out.println(input); //오류 확인하기 위한
        System.out.println(quizService.playQuiz(input));//씨소

        //게임을 실행해서
        //정답이 맞으면(true) "정답입니다" 전달
        if(quizService.playQuiz(input)) {
            model.addAttribute("msg", "정답입니다.");

        }else{
            //정답이 아니면(false) "오답입니다"전달
            model.addAttribute("msg","오답입니다.");
        }
        return "answer";

    }
}




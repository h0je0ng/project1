package com.example.quiz.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data // 게터세터투스트링,이퀄스,해시코드 ~~싹다 만들어줘
@NoArgsConstructor //기본생성자 자동 생성
@AllArgsConstructor //모든 필드를 매개변수로 받는 생성자를 자동 생성
public class QuizDto {

    private Integer id;//객체로 사용하기 위해서 int로 안씀 (써도 되긴해)
    private String question;
    private Boolean answer;
    private String author;


    //id를 제외하고 값을 입력받는 생성자 추가 (우클릭-> generate->constructor)
    // 우리는 지금 아이디를 자동으로 만들어 주기 때문에 id 제외
    public QuizDto(String question, Boolean answer, String author) {
        this.question = question;
        this.answer = answer;
        this.author = author;
    }
}

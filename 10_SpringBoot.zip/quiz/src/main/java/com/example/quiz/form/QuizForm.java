package com.example.quiz.form;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor//모든 필드를 매개변수로 받는 어노텡
public class QuizForm {
    private Integer id;

    @NotBlank //공백이 없어야할때
    private String question;

    //@NotBlank 이거 안먹혀 불린타입이라.
    private Boolean answer;

    @NotBlank
    private String author; // 여기까진 퀴즈dto와 변수 같음
    private Boolean newQuiz; // 퀴즈 등록 또는 변경 확인용

}

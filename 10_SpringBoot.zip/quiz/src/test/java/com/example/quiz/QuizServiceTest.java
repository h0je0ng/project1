package com.example.quiz;

import com.example.quiz.Dto.QuizDto;
import com.example.quiz.service.QuizService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

//테스트를 제공하는 기본적인 스프링부트 테스트 어노테이션
//이거쓰면 알아서 자동으로 읽어오고 빈등록하고 ~~다 알아서해
@SpringBootTest
public class QuizServiceTest {

    @Autowired //퀴즈 서비스(QuizService.java)의 메서드를 테스트 하기 위해 의존성주입
    private QuizService quizService;

    @Test //테스트용도다
    void testQuiz(){
        QuizDto quiz = new QuizDto("질문1", true, "테스터1"); //ox게임이라 정답은 true
        int result = quizService.addQuiz(quiz);

        System.out.println(quiz);

        //실행 결과와 예상되는 결과가 동일한지 확인
        assertThat(result).isEqualTo(1);//assertThat 제이유닛

    }
    @Test
    void listAllTest(){ //전체리스트(목록) 개수
        QuizDto quiz = new QuizDto("질문2",false,"테스터2");
        quizService.addQuiz(quiz);

        List<QuizDto> result = quizService.listAll();

        System.out.println(result);
        System.out.println(quiz.getId());
        assertThat(result.size()).isEqualTo(quiz.getId());

    }
    @Test
    void findQuizTest(){
        QuizDto quiz = new QuizDto("1+1=2",true,"테스터1");
        quizService.addQuiz(quiz);//퀴즈 추가

        QuizDto dto = quizService.findQuiz(quiz.getId());
        assertThat(dto.getQuestion()).isEqualTo(quiz.getQuestion());


    }
    @Test
    void changeQuizTest(){
        QuizDto quiz = new QuizDto("2+2=5",false,"테스터1");
        quizService.addQuiz(quiz);

        quiz.setAnswer(false);
        int result = quizService.changeQuiz(quiz); //해당하는 내용으로 업데이트 수행
        assertThat(result).isEqualTo(1);//한건


    }

    @Test
    void removeQuiz() {
        QuizDto quiz = new QuizDto("1+2=3", true, "테스터1");
        quizService.addQuiz(quiz);

        int result1 = quizService.removeQuiz(quiz.getId());
        assertThat(result1).isEqualTo(1);

        QuizDto result2 = quizService.findQuiz(quiz.getId());
        assertThat(result2).isNull();
    }


    @Test
    void randomQuizTest(){
        quizService.removeAll();

        List<QuizDto> addList = new ArrayList<>();
        addList.add(new QuizDto("1+1=2",true,"테스터1"));
        addList.add(new QuizDto("5+1=9",false,"테스터2"));
        addList.add(new QuizDto("1+101=102",true,"테스터3"));
        addList.add(new QuizDto("6+11=2",false,"테스터4"));
        addList.add(new QuizDto("1+5=6",true,"테스터5"));

        //db저장
        for (QuizDto list: addList)
            quizService.addQuiz(list);

        QuizDto rQuiz = quizService.randomQuiz();
        assertThat(addList).contains(rQuiz);
    }


    @Test
    void playQuizTest(){
        QuizDto quiz = new QuizDto("1+1=2", true , "테스터1");
        quizService.addQuiz(quiz);

        Map map = new HashMap();
        map.put("id",quiz.getId());
        map.put("answer", true); //정답

        boolean result=quizService.playQuiz(map);
        assertThat(result).isTrue();

        map.put("id",quiz.getId());
        map.put("answer", false);//오답입력
        result = quizService.playQuiz(map);
        assertThat(result).isFalse();
    }

}

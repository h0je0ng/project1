package com.example.demo.entity;

import com.example.demo.constant.OrderStatus;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="orders")
@Data
public class Order {

    @Id
    @Column(name="order_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    //양방향 (이거 설정할땐 기준을 잘 생각)
    @ManyToOne
    @JoinColumn(name="member_id")
    private Member member;
    private LocalDateTime orderDate;

    @Enumerated(EnumType.STRING)
    private OrderStatus orderStatus;


    //OrderItem 엔티티의 Order에 의해서 관리 된다라는 의미
    //연관관계의 주인의 필드인 order를 설정
    //고아객체삭제 orphanRemoval=true
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval=true, fetch = FetchType.LAZY)
    private List<OrderItem> orderItems = new ArrayList<>();


    private LocalDateTime regTime;
    private LocalDateTime updateTime;

}

package com.example.demo.entity;

import com.example.demo.constant.Role;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name="member")
@Data
public class Member {

    @Id
    @Column(name="member_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY) //auto_increment자동으로 설정해줌
    private Long memberId;

    @Column(unique = true)//중복x unique
    private String id;
    private String name;

    @Column(unique = true)
    private String email;
    private String password;

    @Enumerated(EnumType.STRING) //이넘을 매핑하는 어노테이션
    private Role role;


}

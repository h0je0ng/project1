package com.example.demo.repository;

import com.example.demo.entity.Board;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface BoardRepository extends JpaRepository<Board, Long> {

    //게시글 제목으로 찾기
    List<Board> findByTitle(String title);

    //게시글 제목 또는 내용으로 검색
    List<Board> findByTitleOrContent(String title, String content);

    //설정한 조회수보다 조회수가 적은 게시글 조회
    List<Board> findByCntLessThan(Integer cnt);

    List<Board> findByCntLessThanOrderByCntDesc(Integer cnt);

    //게시글의 내용을 입력받아서 해당 내용을 포함하고 있는 데이터를 조회
    //조회수가 높은 순으로 정렬

    @Query(value = "select * from Board b where b.content like " +
            " %:content% order by b.cnt desc", nativeQuery = true)
    List<Board> findByContent(@Param("content") String content);
}

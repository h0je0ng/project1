package com.example.demo.entity;

import com.example.demo.constant.ItemSellStatus;
import jakarta.persistence.*;
import lombok.Data;
import org.springframework.boot.autoconfigure.web.WebProperties;
import org.springframework.data.annotation.CreatedDate;

import java.time.LocalDateTime;
import java.util.Stack;

@Entity
@Table(name="item")
@Data
public class Item {
    @Id
    @Column(name="item_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50)
    private String itemName;


    @Column(nullable = false)
    private int price;
    private int stockNumber;

    @Lob
    @Column(nullable = false)
    private String itemDetail;

    @Enumerated(EnumType.STRING)
    private ItemSellStatus itemSellStatus;

    @CreatedDate //시간을 자동으로 저장
    private LocalDateTime regTime;

    @CreatedDate
    private LocalDateTime updateTime;


}

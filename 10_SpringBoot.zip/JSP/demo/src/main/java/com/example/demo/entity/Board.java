package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity  //JPA에서 관리하는 테이블
@Table(name="board") //생성테는 테이블의 이름을 설정
@Data
public class Board {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="board_no")
    private Long no;

    @Column(nullable = false, length=100)  //not null
    private String title;

    @Column(name="writer", nullable = false)
    private String writer;

    @Lob
    @Column(nullable = false)
    private String content;

    private LocalDateTime createDate;

    private int cnt;
}

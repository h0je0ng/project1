package com.example.demo.constant;

public enum OrderStatus {
    ORDER, CANCEL
}

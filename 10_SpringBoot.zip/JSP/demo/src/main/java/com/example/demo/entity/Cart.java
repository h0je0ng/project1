package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "cart")
@Data
public class Cart {

    @Id
    @Column(name="cart_id")
    @GeneratedValue
    private Long id;


    //즉시로딩 : 엔티티를 조회할때 매핑된 엔티티도 한번에 조회
    @OneToOne(fetch = FetchType.LAZY) //(1대1 관계)
    @JoinColumn(name= "member_id") //매핑할 외래키를 지정 (외래키를 지정해 주는 것)
    private Member member;


}

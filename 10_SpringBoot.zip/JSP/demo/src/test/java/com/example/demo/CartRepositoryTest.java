package com.example.demo;


import com.example.demo.constant.Role;
import com.example.demo.entity.Cart;
import com.example.demo.entity.Member;
import com.example.demo.repository.CartRepository;
import com.example.demo.repository.MemberRepository;
import jakarta.persistence.*;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@Transactional
public class CartRepositoryTest {

    @Autowired
    CartRepository cartRepository;

    @Autowired
    MemberRepository memberRepository;

    @PersistenceContext
    EntityManager em;


    @Test
    @DisplayName("장바구니-회원 엔티티 매핑 조회 테스트")
    public void findCartAndMemberTest(){
        Member member = new Member();
        member.setId("test1");
        member.setName("김그린");
        member.setEmail("test1@naver.com");
        member.setRole(Role.USER);

        memberRepository.save(member);

        Cart cart = new Cart();
        cart.setMember(member);
        cartRepository.save(cart);

        //플러시를 하는 이유
        //회원엔티티와 장바구니 엔티티를 영속성 컨텍스트에 저장한 다음
        //엔티티 매니저로 부터 강제로 flush()호출하여 데이터 베이스에 반영
        em.flush();

        //데이터베이스에서 자료를 조회하는지 확인하기위하여
        //영속성 컨텍스트를 비움
        em.clear();

        Cart saveCart = cartRepository.findById(cart.getId())
                .orElseThrow(EntityNotFoundException::new); //카트가 존재하지 않으면 해당하는 예외를 발생 시켜라

        assertThat(saveCart.getMember().getMemberId()).isEqualTo(member.getId());




    }


}

package com.example.demo;

import com.example.demo.entity.Board;
import com.example.demo.entity.QBoard;
import com.example.demo.repository.BoardRepository;
import com.querydsl.jpa.impl.JPAQuery;
import com.querydsl.jpa.impl.JPAQueryFactory;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDateTime;
import java.util.List;

@SpringBootTest
public class BoardRepositoryTest {

    @Autowired
    BoardRepository boardRepository;

    //EntityManeger를 빈으로 주입할 때 사용하는 어노테이션
    @PersistenceContext
    EntityManager em;

    @Test
    @DisplayName("게시글 저장 테스트")
    public void createBoardTest() {
        Board board = new Board();
        board.setTitle("테스트1");
        board.setWriter("김그린");
        board.setContent("내용1");
        board.setCnt(0);
        board.setCreateDate(LocalDateTime.now());

        Board savedBoard = boardRepository.save(board);
        System.out.println(savedBoard);
    }

    public void createBoardList() {
        for (int i=1; i<=10; i++) {
            Board board = new Board();
            board.setTitle("테스트"+i);
            board.setWriter("테스터" + i);
            board.setContent("내용" + i);
            board.setCnt(i);
            board.setCreateDate(LocalDateTime.now());

            Board savedBoard = boardRepository.save(board);
        }
    }

    @Test
    @DisplayName("게시글 조회 테스트")
    public void findByTitleTest() {
        this.createBoardList();
        List<Board> boardList = boardRepository.findByTitle("테스트1");
        for (Board board : boardList) {
            System.out.println(board);
        }

    }

    @Test
    @DisplayName("제목 or 내용 테스트")
    public void findByTitleOrContentTest() {
        this.createBoardList();
        List<Board> boardList = boardRepository.findByTitleOrContent("테스트1", "내용5");
        for (Board board : boardList) {
            System.out.println(board);
        }

    }

    @Test
    @DisplayName("조회수 Lessthan테스트")
    public void findByCntLessThanTest() {
        this.createBoardList();
        List<Board> boardList = boardRepository.findByCntLessThan(5);
        for (Board board : boardList) {
            System.out.println(board);
        }

    }

    @Test
    @DisplayName("조회수 Lessthan 내림차순 정렬 테스트")
    public void findByCntLessThanOrderByCntDescTest() {
        this.createBoardList();
        List<Board> boardList = boardRepository.findByCntLessThanOrderByCntDesc(5);
        for (Board board : boardList) {
            System.out.println(board);
        }

    }

    @Test
    @DisplayName("@Query를 이용하여 게시글 조회 테스트")
    public void findByContentTest() {
        this.createBoardList();
        List<Board> boardList = boardRepository.findByContent("내용");
        for (Board board : boardList) {
            System.out.println(board);
        }

    }

    @Test
    @DisplayName("QueryDsp 조회 테스트1")
    public void querDslTest() {
        this.createBoardList();
        JPAQueryFactory queryFactory = new JPAQueryFactory(em);
        QBoard qBoard = QBoard.board;
        JPAQuery<Board> query = queryFactory.selectFrom(qBoard)
                .where(qBoard.writer.eq("테스터1"))
                .where(qBoard.content.like("%" + "내용" + "%"))
                .orderBy(qBoard.cnt.desc());

        List<Board> boardList = query.fetch();

        for (Board board : boardList) {
            System.out.println(board);
        }
    }
}

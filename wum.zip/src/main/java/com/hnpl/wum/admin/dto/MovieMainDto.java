package com.hnpl.wum.admin.dto;

import lombok.Data;

@Data
public class MovieMainDto {

    private Long movieSeq;

    private String movieName;

    private String poster;
}

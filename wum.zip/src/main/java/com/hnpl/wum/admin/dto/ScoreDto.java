package com.hnpl.wum.admin.dto;

import lombok.Data;

@Data
public class ScoreDto {

    private Integer score;
    private String reviewId;
    private String reviewContent;
    private String postDate;

}

package com.hnpl.wum.user.constant;

public enum Role {
    USER,ADMIN;
}

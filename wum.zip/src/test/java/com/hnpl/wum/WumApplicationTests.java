package com.hnpl.wum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WumApplicationTests {

	@Test
	void contextLoads() {
	}

}

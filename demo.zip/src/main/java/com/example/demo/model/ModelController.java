package com.example.demo.model;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("hello")
public class ModelController {

    @GetMapping("model") //겟 방식으로 불러 올것
    public String helloView(Model model){
        model.addAttribute("msg","타임리프");

        Member m = new Member("aaa","김그린");
        model.addAttribute("obj",m);

        List<Member> memberList = new ArrayList<>();
        memberList.add(new Member("bbb","이자바"));
        memberList.add(new Member("ccc","최제이"));
        memberList.add(new Member("ddd","정디비"));

        model.addAttribute("list", memberList);

        Map<String, Member> memberMap = new HashMap<>();
        memberMap.put("1", new Member("eee","이그린"));
        memberMap.put("2", new Member("fff","오초록"));

        model.addAttribute("map",memberMap);


        return "helloThymeLeaf";
    }

}

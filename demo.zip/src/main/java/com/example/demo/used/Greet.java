package com.example.demo.used;

public interface Greet {
    void greeting();
}


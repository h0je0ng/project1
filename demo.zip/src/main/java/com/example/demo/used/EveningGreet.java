package com.example.demo.used;

//사용 되는 클래스
//@Component
public class EveningGreet implements Greet{
    @Override
    public void greeting() {
        System.out.println("-------------");
        System.out.println("좋은 저녁입니다");
        System.out.println("-------------");
    }
}

package com.example.demo.used;

public class GreetMain {
//    public static void main(String[] args) {
//        EveningGreet mg = new EveningGreet();
//        mg.greeting();
//
//    }
}

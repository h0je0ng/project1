package com.example.demo.param;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PathVariableController {

    @GetMapping("showPath")
    public String showView() {
        return "showPath";
    }

    //@PathVariable : URL경로에서 변수를 추출해서 매서드의 파라미터로 전달
    @GetMapping("/function/{no}")
    public String selectFunction(@PathVariable Integer no) {
        String view = null;
        switch (no) {
            case 1:
                view = "pathvariable/function1";//앞에 pathvariable폴더이름, function1.html파일
                break;
            case 2:
                view = "pathvariable/function2";
                break;
            case 3:
                view = "pathvariable/function3";
                break;

        }
            return view;
    }
    //쇼패스.html 에서 지정해준 경로가 3개 로 다 달랐기 떄문에 일일이 지정

    //params속성에 버튼에 대응하는 name속성을 설정하면
    //같은 url에 post로 전달된 요청에서 어느 버튼이 클릭된건지 판별
    //params="a"-> 전달되는 내용에서 a라는 변수가 있는지 확인하는것
    // (네임의 속성이라기 보단 버튼의 이름을 붙여준 느낌)
    @PostMapping(value="send", params = "a")
    public String showAView(){
        return "submit/a";
    }
    @PostMapping(value="send", params = "b")
    public String showBView(){
        return "submit/b";
    }
    @PostMapping(value="send", params = "c")
    public String showCView(){
        return "submit/c";
    }
}

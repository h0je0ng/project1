package com.example.demo.param;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class RequestParamController {
    //화면에 보이게 주소에 http://localhost:8080/showView치면 나오게
    @GetMapping("showView")
    public String showView(){
        return "entry";
        //entry.html뷰로 전송
    }
//    @PostMapping("confirm")//포스트방식으로 받아옴
//    public String confirmView(Model model,
//                              @RequestParam String name, //entry.html의 폼에서 NAME속성과 동일한 이름을 지정했음 (리퀘스트 파람에)
//                              @RequestParam Integer age,
//                              @DateTimeFormat(iso= DateTimeFormat.ISO.DATE)
//                                  @RequestParam LocalDate birth){
//        model.addAttribute("name",name);
//        model.addAttribute("age",age);
//        model.addAttribute("birth",birth);
//
//        return "confirm";
//        //리턴하는 뷰의 이름이 confrim, 그래서 엔트리에서 받아와서 출력할 confirm.html을 만들어줘(보여주는 창)
//    }

    @PostMapping("confirm") //confrim2
    public String confirmView(@ModelAttribute("myForm")ParamForm f){//모델 어트리뷰트로 myform이라고 이름을 지정
        return  "confirm2";


    }
}

package com.example.demo.param;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

@Data
public class ParamForm {
    private String name;//여기이름이 같으면 자동으로 연결됨, 데이터타입도 여기서지정한대로 자동으로 지정
    private Integer age;

    @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) //년월일 방식으로
    private LocalDate birth;
}

package com.example.demo.db.dao;

import com.example.demo.db.dto.MemberDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface MemberMapper {
    //추상메서드의 이름은
    //반드시 mapper의 id와 동일!!
    public List<MemberDto> list();
}

package com.example.demo.db.service;

import com.example.demo.db.dao.MemberMapper;
import com.example.demo.db.dto.MemberDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MemberService {

    @Autowired
    private MemberMapper memberMapper;

    // 모든 멤버 정보를 조회하는 메서드
    public List<MemberDto> list(){
        List<MemberDto> list = memberMapper.list();
        return  list;
    }
}
/* 1. MemberService.java 파일이 로드되고 Spring Boot 애플리케이션 컨텍스트에 MemberService 빈으로 등록된다.
   2. MemberMapper 빈이 MemberService에 주입되고 의존성이 설정된다. */
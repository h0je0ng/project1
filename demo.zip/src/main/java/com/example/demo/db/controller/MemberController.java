package com.example.demo.db.controller;

import com.example.demo.db.dto.MemberDto;
import com.example.demo.db.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController //해당결과를 json형태로 반환(뷰가 없기 때문에 컨트롤러말고 RestController )
public class MemberController { //서비스 사용

    @Autowired
    private MemberService memberService;

    // 모든 멤버의 이름을 반환하는 API 엔드포인트
    @GetMapping("/all")
    public String allMembers(){
        // 모든 멤버 정보를 가져옴
        //이름만 출력
        List<MemberDto> memberList  = memberService.list();

        StringBuilder sb = new StringBuilder();

        // 각 멤버의 이름을 공백으로 구분하여 StringBuilder에 추가
        for(MemberDto m : memberList){
            sb.append(m.getName()+ " ");
        }
        // StringBuilder에 있는 모든 이름을 문자열로 반환

        return sb.toString();
    }

}
/* 3. MemberController.java 파일이 로드되고 Spring Boot 애플리케이션 컨텍스트에 MemberController 빈으로 등록된다.
   4. MemberService 빈이 MemberController에 주입되고 의존성이 설정된다.
   5. /all 엔드포인트가 등록되고 GET 요청을 처리하는 메서드가 매핑된다. */

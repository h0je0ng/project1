package com.example.demo.db.dto;

import lombok.*;

@Data //getter, setter, hashCode(), equals(), toString (싹 다 만들어줌 롬복이)
//@Getter @Setter @ToString @EqualsAndHashCode 이렇게도 사용할수 있어
@NoArgsConstructor //기본생성자 자동 생성
@AllArgsConstructor // 모든 필드를 매개변수로 갖는 생성자
// @RequiredArgsConstructor //final이나 notnull한 필드를 매개변수로 갖는 생성자 (여기서는 필요없지만 알려줌)
public class MemberDto {
    private Integer id;// 멤버 ID
    private String name;


}
/* 6. MemberDto.java 파일이 로드되고 Lombok을 사용하여 Getter, Setter, Equals, HashCode, ToString 메서드가 자동 생성된다. */
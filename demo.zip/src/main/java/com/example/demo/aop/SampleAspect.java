package com.example.demo.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import java.util.Date; // java.util.Date 임포트 추가
import java.text.SimpleDateFormat;

@Aspect
@Component
public class SampleAspect {

    @Before("execution(* com.example.demo.used.*Greet.*(..))")
    public void beforeAdvice(JoinPoint joinPoint){
        System.out.println("-------Before Advice----------");
        System.out.println(new SimpleDateFormat("yyyy/MM/dd").format(new Date()));
        System.out.println(String.format("메서드:%s",joinPoint.getSignature().getName())); // 'jointPoint'의 오타 수정
    }

    @After("execution(* com.example.demo.used.*Greet.*(..))")
    public void afterAdvice(JoinPoint joinPoint){ // 메서드 이름 변경
        System.out.println("-------After Advice----------");
        System.out.println(new SimpleDateFormat("yyyy/MM/dd").format(new Date()));
        System.out.println(String.format("메서드:%s",joinPoint.getSignature().getName())); // 'jointPoint'의 오타 수정
    }

    @Around("execution(* com.example.demo.used.*Greet.*(..))")
    public Object aroundAdvice(ProceedingJoinPoint joinPoint) throws Throwable { // 메서드 이름 변경 및 반환 타입 변경
        System.out.println("-------Around Advice----------");

        System.out.println("** 처리 전 **");
        Object result = joinPoint.proceed();
        System.out.println("** 처리 후 **");

        return result;
    }
}

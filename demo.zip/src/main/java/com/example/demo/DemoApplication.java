package com.example.demo;

import com.example.demo.used.Greet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//스트링부트의 실행 클래스(사용하는 클래스)
@SpringBootApplication
public class DemoApplication {

	@Autowired
	Greet greet;//greet인터페이스 선언

	public static void main(String[] args) {

		SpringApplication.run(DemoApplication.class, args).getBean(DemoApplication.class).execute();
												//이 매개변수를 가지고 데모 애플리캐이션을 실행해라 는 뜻
	}

	private void execute(){
		greet.greeting();
	}

}

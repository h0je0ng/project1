package com.example.demo.validation.validator;

import com.example.demo.validation.form.CalcForm;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

//1. 스프링프레임워크가 제공하는 validator 인터페이스를 구현
@Component //빈등록
public class CalcValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {//<?>어느타입이던 다 상관없이 다된다는 뜻
        //인수로 전달받은 form이 입력체크의 대상인지 논리 값으로 확인함
        // CalcVForm과 호환이 되는지 확인 /호환이 가능하면 트루, 안되면 펄스
        return CalcForm.class.isAssignableFrom(clazz);
    }
    @Override
    public void validate(Object target, Errors errors) {
        //유효성검사를 수행할 Form을 얻어옴
        CalcForm form = (CalcForm) target;
    }
        //값이입력되어있는지 먼저 확인
  if (form.getLeftNum() != null && form.getRightNum() != null) {
        //왼쪽이 홀수, 오른쪽이 짝수가 아닌 경우에
        if (!((form.getLeftNum() % 2 == 1) && (form.getRightNum() % 2 == 0))) {
                //발생한 에러를 Errors객체에 추가
                //Errors인터페이스의 reject 메서드에 에러메시지의 키를 지정함
                errors.reject("com.example.demo.validator.CalcValidator.message");

            }
        }
    }





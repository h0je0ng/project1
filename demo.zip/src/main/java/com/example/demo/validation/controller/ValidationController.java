package com.example.demo.validation.controller;

import com.example.demo.validation.form.CalcForm;
import com.example.demo.validation.validator.CalcValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ValidationController {

    //@ModelAttribute : 클라이언트가 전달하는 값을 객체로 매핑해주는 역할
    //폼에 데이터를 바인딩 하기 위한 초기화 작업을 수행

    //Form-backing Bean: <form>태그에 바인딩되는 form클래스 인스턴스
    //@ModelAttribute를 사용해서 연결함 ->setUpForm() 메서드를 동작 -> CalcForm 객체 생성->
    // CalcForm 객체의 폼에서 각각의 메서드를 읽고, 게터세터로 내용 설정 그 내용을 가지고 유효성 검사를 해
    // -> 그 유효성 검사의 결과를 BindingResult가  받아옴
    // 그래서 유효성 검사를 하기 위해서는 모델 어트리뷰트가 필수야
    //새로운 객체를 리턴하겠다,
    @ModelAttribute
    public CalcForm setUpForm(){
        return new CalcForm();
    }
    @GetMapping("showCal")
    public String showView(){
        return "calculator";
    }
    //@BindingResult : 유효성 검사를 실행한 결과(에러정보)를 보관
    @PostMapping("calc")
    public  String confirmView(@Validated CalcForm form,//유효성 검사를 위해서 @Validated(단일항목 검사)
                               BindingResult bindingResult,
                               Model model){

        //hesError가 true면
        // 에러가 있으면 입력화면으로 리턴
        if(bindingResult.hasErrors()){
            return "calculator";
        }
        //에러가 없으면 정보를 받아와
        Integer result = form.getLeftNum() + form.getRightNum();
        model.addAttribute("result",result);
        return "resultCal";
    }

    //2. 컨트롤러에서 직접 작성한 커스텀 유효성 검사기를 주입하고( @Autowired)
    // [CalcValidator에서 만든 거를 @Autowired해서 빈 등록해야 쓸수 있어 (의존성 주입)]
    //WebDataBinder인터페이스의 addValidators 메서드로
    //커스텀유효성 검사기를 등록하면 됨
    @Autowired
    CalcValidator calcValidator;

    //커스텀 유효성 검사기를 등록함
    //calcForm 객체에 대해 유효성 검사를 수행하도록 등록함
    //객체 명을 등록하지 않으면 모든 객체에 대해서 검사를 수행함
    @InitBinder("calcForm")
    public void initBinder(WebDataBinder webDataBinder){
        webDataBinder.addValidators(calcValidator);
    }

}

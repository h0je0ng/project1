package com.example.demo.validation.form;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

@Data
public class CalcForm {
    //유효성검사
    @NotNull
    @Range(min=1,max =100) //여기에있던 메세지 들을 프로퍼티스에 추가 함
    private Integer leftNum;

    @NotNull
    @Range(min=1,max =100)
    private Integer rightNum;
}

package com.green.shop.cart.dto;

public class CartListDto {
    private Long itemId;

    private String itemName;

    private Integer price;

    private Long itemImgId;

    private String imgName;

    private String oriImgName;

    private String imgUrl;

    private String repImgYn;
}


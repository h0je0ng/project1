package com.green.shop.member.constant;

public enum Role {
    USER, ADMIN;
}

package com.green.shop.member.controller;

import com.green.shop.member.constant.Role;
import com.green.shop.member.dto.MemberDto;
import com.green.shop.member.form.MemberJoinForm;
import com.green.shop.member.service.MemberService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@RequestMapping("/members")
@Controller
public class MemberController {

    @Autowired
    MemberService memberService;

    @GetMapping("/new")
    public String memberForm(Model model, HttpServletRequest request){
        CsrfToken token = (CsrfToken)request.getAttribute("_csrf");
        System.out.println(token.getHeaderName()+"="+token.getToken());

        model.addAttribute("memberJoinForm", new MemberJoinForm());
        return "member/memberJoinForm";
    }

    //Valid :유효성 검사 어노텡
    //BindingResult 발생한 오류를 받아오는 곳
    //폼에 입력된 데이터의 유효성 검사를 실시 (멤버조인폼 사용)
    @PostMapping("/new")
    public String newMember(@Valid MemberJoinForm memberJoinForm,
                            BindingResult bindingResult,
                            Model model,
                            RedirectAttributes rttr) {


        //유효성 검사에서 오류가 있다면
        //회원가입 페이지로 이동
       if (bindingResult.hasErrors()) {
            return "member/memberJoinForm";
        }

      try { //오류가 없다면
        // 폼에 입력된 내용을 가져옴
        MemberDto dto = new MemberDto();
        dto.setId(memberJoinForm.getId());
        dto.setPassword(memberJoinForm.getPassword());
        dto.setName(memberJoinForm.getName());
        dto.setEmail(memberJoinForm.getEmail());
        dto.setAddress(memberJoinForm.getAddress());
        dto.setRole(Role.USER);//유저 회원가입
//        dto.setRole(Role.ADMIN);//관리자 회원가입



        //가져온 내용을 서비스를 이용하여 회원가입을 진행
        memberService.insertMember(dto);

        //model을 이용하여 데이터를 전달하면
        // redirect 에서 메세지가 유지 되지 않음 새로 접속하는 것이기 떄문에 내용이 안나타나
        // RedirectAttributes 선언

        // model.addAttribute("joinMessage","회원가입을 환영합니다. ");
        // addFlashAttribute은 1회성으로 띄울때 사용


        rttr.addFlashAttribute("joinMessage","회원가입을 환영합니다. ");
        System.out.println(memberJoinForm.toString());

    } catch(IllegalStateException e){

        System.out.println(e.getMessage());
        model.addAttribute("errorMessage", e.getMessage());
        return "member/memberJoinForm";
    }

        //회원가입 시에 중복된 이메일 또는 아이디가 있으면
        //다시 회원가입 페이지로 이동
        // 회원가입에 성공하면 메인페이지로 이동
        return "redirect:/";
    }

    @GetMapping("/login")
    public String loginForm(){
        return "/member/memberLoginForm";
    }
    @GetMapping(value="/login/error")
    public String loginError(Model model){
        model.addAttribute("loginErrorMsg", "아이디 또는 비밀번호를 확인하세요");

        return "/member/memberLoginForm";
    }
}

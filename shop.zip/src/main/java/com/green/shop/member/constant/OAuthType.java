package com.green.shop.member.constant;

public enum OAuthType {
    GREEN, KAKAO, GOOGLE, NAVER
}

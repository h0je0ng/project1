package com.green.shop.member.controller;


import com.green.shop.member.dto.MemberDto;
import com.green.shop.member.service.KakaoLoginService;
import com.green.shop.member.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class KakaoLoginController {

    @Autowired
    private KakaoLoginService kakaoLoginService;

    @Autowired
    private MemberService memberService;
    @Autowired
    private AuthenticationManager authenticationManager;

    @Value("${kakao.default.password}")
    private String kakaoPassword;


    @GetMapping("/members/kakao")
    public  String kakaoCallback(String code) {

        // 인증 서버로부터 code를 이용하여 액세스 토큰을 받아옴
        String accessToken = kakaoLoginService.getAccessToken(code);

        // 사용자 정보 받아오기
        MemberDto memberInfo = kakaoLoginService.getMemberInfo(accessToken);

        //롱으로 썼기 때문에 아마 예외 발생, 그래서 예외 처리
//        try {
//            Long memberId = memberService.findMemberId(memberInfo.getId());
//        }catch (Exception e){
//            memberService.insertMember(memberInfo);
//        }

        memberService.insertMember(memberInfo);

        //아이디와 비밀번호를 사용하여 사용자 인증을 위한 객체를 생성
        UsernamePasswordAuthenticationToken authenticationToken =
                new UsernamePasswordAuthenticationToken(memberInfo.getId(),kakaoPassword);

        //생성한 객체를 사용하여 인증을 수행
        Authentication authentication  = authenticationManager.authenticate(authenticationToken);

        //인증정보를 설정
        SecurityContextHolder.getContext().setAuthentication(authentication);

        return "redirect:/";
    }
}

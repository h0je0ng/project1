package com.green.shop.member.service;

import com.google.gson.Gson;
import com.green.shop.member.constant.OAuthType;
import com.green.shop.member.constant.Role;
import com.green.shop.member.dto.MemberDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Service
public class KakaoLoginService {

    @Value("${kakao.default.password}")
    private String KakaoPassword;

    public String getAccessToken(String code) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-type", "application/x-www-form-urlencoded;charset=utf-8");

        MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
        body.add("grant_type", "authorization_code");
        body.add("client_id", "d353f76b981517b3f7bfb72b76a676b8");
        body.add("redirect_uri", "http://localhost:8080/members/kakao");
        body.add("code", code);

        HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(body, headers);

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity = restTemplate.exchange(
                "https://kauth.kakao.com/oauth/token",
                HttpMethod.POST,
                requestEntity,
                String.class
        );

        String jsonData = responseEntity.getBody();

        Gson gsonObj = new Gson();
        Map<?, ?> data = gsonObj.fromJson(jsonData, Map.class);

        return (String) data.get("access_token");
    }

    public MemberDto getMemberInfo(String accessToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Bearer " + accessToken);
        headers.add("Content-type", "application/x-www-form-urlencoded;charset=utf-8");

        HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(headers);

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity = restTemplate.exchange(
                "https://kapi.kakao.com/v2/user/me",
                HttpMethod.POST,
                requestEntity,
                String.class
        );

        String memberInfo = responseEntity.getBody();

        Gson gsonObj = new Gson();
        Map<?, ?> data = gsonObj.fromJson(memberInfo, Map.class);

        Double id = (Double) (data.get("id"));
        String nickName = (String) ((Map<?, ?>) (data.get("properties"))).get("nickname");
        String email = (String) ((Map<?, ?>) (data.get("kakao_account"))).get("email");

        MemberDto memberDto = new MemberDto();
        memberDto.setId(Double.toString(id));
        memberDto.setName(nickName);
        memberDto.setEmail(email);
        memberDto.setPassword(KakaoPassword);
        memberDto.setRole(Role.USER);
        memberDto.setOAuth(OAuthType.KAKAO);

        return memberDto;
    }
}

package com.green.shop.member.mapper;

import com.green.shop.member.dto.MemberDto;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MemberMapper {
   int insertMember(MemberDto memberDto);

   //셀렉트 했기 떄문에 MemberDto
   MemberDto overlapId(String id);

   MemberDto overlapEmail(String email);

   MemberDto loginMember(String id);

   Long findMemberId(String id);

}

package com.green.shop.order.constant;

public enum OrderStatus {
    ORDER, CANCEL
}

package com.green.shop.item.dto;

import com.green.shop.item.constant.ItemSellStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
public class ItemMainDto {

    private Long itemId;

    private String itemName;

    private String itemDetail;

    private String imgUrl;

    private Integer price;





}

package com.green.shop.item.constant;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}

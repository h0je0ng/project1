package com.green.shop.item.service;

import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.util.UUID;

@Service
public class FileService {
    public String uploadFile(String uploadPath, String originalFileName,
                                byte[] fileData) throws Exception{

        //* uuid생성
        // 범용 고유 식별자(128비트 16진수로 표현되는 고유의 아이디)
        // 파일명을 저장할때 그대로 저장하지 않는다 .. 한글로 저장시인식 x
        // 그래서 변환해서 저장하는데..
        // uuid를 생성하면 유일한 값을 사용 할때, 절대 중복값을 쓰면 안될때 사용 가능
        //아이디를 랜덤 값으로 변환,지정해 준 것

        UUID uuid = UUID.randomUUID();

        //확장자 추출
        String extension = originalFileName.substring(
                originalFileName.lastIndexOf("."));

        //uuid와 확장자를 조합해서 파일이름을 생성
        String savedFileName = uuid.toString() + extension;

        //파일이 업로드 될 전체 경로를 생성
        String fileUploadFullUrl = uploadPath+"/" +savedFileName;

        //파일 출력 스트림을 생성하고
        //파일 경로에 해당하는 파일을 생성하거나 덮어쓰기 함

        FileOutputStream fos = new FileOutputStream(fileUploadFullUrl);

        //파일기록
        fos.write(fileData);
        //출력스트림 닫기
        fos.close();

        //지정된 파일 이름 반환
        return savedFileName;
    }
    public  void deleteFile(String filePath)throws Exception{
        File deleteFile = new File(filePath); //파일객체 생성

        //파일이 존재하는지 확인
        if(deleteFile.exists()){
            //삭제
            deleteFile.delete();
            System.out.println("파일을 삭제하였습니다");
        }else {
            System.out.println("파일이 존재하지 않습니다.");
        }
    }
}

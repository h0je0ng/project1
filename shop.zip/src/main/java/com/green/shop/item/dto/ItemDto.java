package com.green.shop.item.dto;

import com.green.shop.item.constant.ItemSellStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ItemDto {
    private Long itemId;

    private String itemName;

    private Integer price;

    private int count;

    private Integer stockNumber;

    private String itemDetail;

    private ItemSellStatus itemSellStatus; //열거형으로 만들 것이라면 enum으로 만들어 주는게 좋아

    private LocalDateTime regTime;

    private LocalDateTime updateTime;

}

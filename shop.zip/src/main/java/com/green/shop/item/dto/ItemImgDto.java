package com.green.shop.item.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ItemImgDto {
    private Long itemImgId;

    private String imgName;//이미지 이름

    private String oriImgName;//원본 이미지 이름(이렇게 원본 따로 지정)

    private String imgUrl;//이미지 경로

    private String repImgYn;//대표이미지 확인

    private Long itemId; //기본키와 외래키는 타입을 맞춰줘[외래키]

    private LocalDateTime regTime;

    private LocalDateTime updateTime;


}

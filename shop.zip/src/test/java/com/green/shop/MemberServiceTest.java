package com.green.shop;


import com.green.shop.member.constant.Role;
import com.green.shop.member.dto.MemberDto;
import com.green.shop.member.service.MemberSecurityService;
import com.green.shop.member.service.MemberService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.assertThrows;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders.formLogin;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class MemberServiceTest {

    @Autowired
    private MemberService memberService;

    @Autowired
    private MemberSecurityService memberSecurityService;

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("회원 가입 테스트 ")
    public void insertMemberTest(){
        MemberDto member = new MemberDto();
        member.setId("test11");
        member.setPassword("123456789");
        member.setName("호정");
        member.setEmail("test11@naver.com");
        member.setAddress("서울");
        member.setRole(Role.USER);

        System.out.println(member);
        int result= memberService.insertMember(member);
        assertThat(result).isEqualTo(1); //수행되는 건수가 한건임 (결과가 수행되는 한건 건수와 같아야해)

    }
    @Test
    @DisplayName("중복 테스트")
    public void overlapTest(){
        MemberDto memberDto = new MemberDto();

        memberDto.setId("test11");
        memberDto.setEmail("test11@naver.com");


        //람다식 사용 x
        Throwable th = null;

        try{
            memberService.insertMember(memberDto);
        }catch (IllegalStateException e){
            th = e;
        }

        System.out.println(th.getMessage());
        assertThat(th.getMessage()).isIn("중복된 아이디","이미 가입한 회원");

        //람다식 사용 :메서드를 "하나의 식"으로 표현한 것
        Throwable th2 = assertThrows(IllegalStateException.class,() -> memberService.insertMember(memberDto));
        System.out.println(th2.getMessage());
        assertThat(th2.getMessage()).isIn("중복된 아이디","이미 가입한 회원");

    }
    @Test
    @DisplayName("로그인 테스트")
    public void loginMemberTest() throws Exception{
        String id = "hj";
        String password = "123456789";

        //로그인 요청을 모방
        mockMvc.perform(formLogin().userParameter("id") //로그인 시 사용자의 이름을 나타내는 부분
                .loginProcessingUrl("/members/login") //로그인을 처리할 url주소
                .user(id).password(password))//로그인 요청에 사용될 아이디와 비번 설정
                .andExpect(SecurityMockMvcResultMatchers.authenticated());//로그인을 성공하고 사용자가 인증되었는지 검증

        //로그아웃 요청을 보냄
        mockMvc.perform(MockMvcRequestBuilders.get(
                                "/members/logout"))
                .andExpect(status().is3xxRedirection());

        //로그아웃 후 로그인 되지 않은 상태 인지 확인
        mockMvc.perform(MockMvcRequestBuilders.get("/"))
                .andExpect(SecurityMockMvcResultMatchers.unauthenticated());
    }


}

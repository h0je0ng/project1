package com.hnpl.datalab.demo.chart;

import lombok.Data;

@Data
public class ChartDto {
    private Long yearKey;
    private String injury;
    private String job;
    private Long peopleNum;
}

package com.hnpl.datalab.demo.index.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IndexChartDTO {
    private Integer yearKey;
    private Integer peopleNum;
    private String injury;
}

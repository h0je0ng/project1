package com.hnpl.datalab.demo.ratio;

import lombok.Data;

@Data
public class RatioDto {

    private Long yearKey;
    private Long yearBy;
    private Long total;
    private double percentage;
    private String injury;

}

package com.hnpl.datalab.demo.index.chart;

import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface IndexChartMapper {
    List<IndexChartDTO> dieList();
    List<IndexChartDTO> accidentList();
}

package com.hnpl.datalab.demo.ratio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class RatioController {

    @Autowired
    RatioService ratioService;

    @GetMapping("/ratio")
    public String getRatio(Model model){
        model.addAttribute("ratios", ratioService.ratioList());
        return "category/ratio";
    }

    @GetMapping("/ratio/chart")
    @ResponseBody
    public List<RatioDto> getRatioChart(){
        return ratioService.ratioList();
    }
    @GetMapping("/ratio/chart2")
    @ResponseBody
    public List<RatioDto> getRatioChart2(){
        return ratioService.ratioList2();
    }
}

package com.hnpl.datalab.demo.chart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ChartService {

    @Autowired
    ChartMapper chartMapper;

    public List<ChartDto> injuredList() {
        return chartMapper.injuredList();
    }

    public List<ChartDto> deadList() {
        return chartMapper.deadList();
    }
}

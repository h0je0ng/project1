package com.hnpl.datalab.demo.ratio;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RatioService {

    @Autowired
    RatioMapper ratioMapper;

    public List<RatioDto> ratioList(){
        return ratioMapper.ratioList();
    }
    public List<RatioDto> ratioList2(){
        return ratioMapper.ratioList2();
    }
}

package com.hnpl.datalab.demo.ratio;

import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface RatioMapper {

    List<RatioDto>  ratioList();
    List<RatioDto>  ratioList2();
}

package com.hnpl.datalab.demo.index.chart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IndexChartService {
    @Autowired
    private IndexChartMapper indexChartMapper;

    public List<IndexChartDTO> dieList(){
        return indexChartMapper.dieList();
    }
    public List<IndexChartDTO> accidentList(){
        return indexChartMapper.accidentList();
    }

}

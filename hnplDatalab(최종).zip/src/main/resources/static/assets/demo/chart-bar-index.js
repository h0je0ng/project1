
async function showDieChart() {
    let url = "/indexChart/die";

    try{
        const response = await fetch(url,{
            method:'GET',
            headers: {
                'Content-Type' : 'application/json'
            },
            cache: 'no-cache'
        });

        if (!response.ok) {
            const errorMessage = await response.text();
            throw new Error(`error message : ${errorMessage}`);
        };

        const responseData = await response.json();

        if(!responseData || responseData.length == 0) {
            throw new Error("empty response data");
        };

        const die = responseData;

        const labels = die.map(item => item.yearKey);
        const chartData = die.map(item => item.peopleNum);

        const ctx = document.getElementById('myDieChart').getContext('2d');

        new Chart(ctx,{
            type : 'line',
            data: {
                labels:labels,
                datasets:[{
                    label: '2014~2022',
                    data: chartData,
                    backgroundColor: 'rgba(700,200,20,0.2)',
                    borderColor: 'rgba(700,200,20,1)',
                    borderWidth:1
                }]
            },
            options:{
                responsive:false,
                scales:{
                    y:{
                        beginAtZero:true
                    }
                }
            }
        })
    }catch(error){
        alert(error.message);
    }
}

async function showAccidentChart() {
    let url = "/indexChart/accident";

    try{
        const response = await fetch(url,{
            method:'GET',
            headers: {
                'Content-Type' : 'application/json'
            },
            cache: 'no-cache'
        });

        if (!response.ok) {
            const errorMessage = await response.text();
            throw new Error(`error message : ${errorMessage}`);
        };

        const responseData = await response.json();

        if(!responseData || responseData.length == 0) {
            throw new Error("empty response data");
        };

        const accidents = responseData;

        const labels = accidents.map(item => item.yearKey);
        const chartData = accidents.map(item => item.peopleNum);

        const ctx = document.getElementById('myAccidentChart').getContext('2d');

        new Chart(ctx,{
            type : 'line',
            data: {
                labels:labels,
                datasets:[{
                    label: '2014~2022',
                    data: chartData,
                    backgroundColor: 'rgba(800,100,20,0.2)',
                    borderColor: 'rgba(800,100,20,1)',
                    borderWidth:1
                }]
            },
            options:{
                responsive:false,
                scales:{
                    y:{
                        beginAtZero:true
                    }
                }
            }
        })
    }catch(error){
        alert(error.message);
    }
}

document.addEventListener('DOMContentLoaded',function(){
    showDieChart();
    showAccidentChart();
})
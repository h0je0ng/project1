window.onload = async function () {
    try {
        const url = "/chart/injured"
        const label1 = "끼임재해자"
        const response = await fetch(url);
        const data = await response.json();

        const labels = data.map(Chart => Chart.peopleNum);  // peopleNum 값을 labels 배열로 변환
        const job = data.map(Chart => Chart.job);  // job 값을 job 배열로 변환

        const ctx = document.getElementById("injuredChart").getContext('2d');
        const rankingChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: job,
                datasets: [{
                    label: label1,
                    data: labels,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    } catch (error) {
        console.error('Error fetching data:', error);
    }

    try {
        const url = "/chart/dead"
        const label2 = "끼임재해 사망자"
        const response = await fetch(url);
        const data = await response.json();

        const labels = data.map(Chart => Chart.peopleNum);
        const job = data.map(Chart => Chart.job);

        const ctx = document.getElementById("deadChart").getContext('2d');
        const rankingChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: job,
                datasets: [{
                    label: label2,
                    data: labels,
                    backgroundColor: 'rgba(200, 50, 50, 0.2)',
                    borderColor: 'rgba(200, 50, 50, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    } catch (error) {
        console.error('Error fetching data:', error);
    }
};


window.onload = async function () {
    async function fetchDataAndRenderChart(url, canvasId, label1, label2) {
        try {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const data = await response.json();
            console.log(data);  // 데이터 확인을 위한 로그 추가

            const labels = data.map(ratio => ratio.yearKey);
            const yearBy = data.map(ratio => ratio.yearBy);
            const total = data.map(ratio => ratio.total);

            const canvas = document.getElementById(canvasId);
            if (!canvas) {
                console.error(`Canvas with id '${canvasId}' not found`);
                return;
            }

            const ctx = canvas.getContext('2d');
            const ratioChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: label1,
                        data: yearBy,
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    },
                    {
                        label: label2,
                        data: total,
                        backgroundColor: 'rgba(200, 50, 50, 0.2)',
                        borderColor: 'rgba(200, 50, 50, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }

    async function fetchDataAndRenderPieCharts(url, url2) {
        try {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const data = await response.json();
            console.log('Data for ratio charts:', data);  // 데이터 확인을 위한 로그 추가

            const response2 = await fetch(url2);
            if (!response2.ok) {
                throw new Error('Network response was not ok');
            }
            const data2 = await response2.json();
            console.log('Data for death charts:', data2);  // 데이터 확인을 위한 로그 추가

            const percentagesByYear = {};
            const deathPercentagesByYear = {};

            data.forEach(ratio => {
                const year = ratio.yearKey;
                const percentage = ratio.percentage;
                if (!percentagesByYear[year]) {
                    percentagesByYear[year] = [];
                }
                percentagesByYear[year].push(percentage);
            });

            data2.forEach(ratio => {
                const year = ratio.yearKey;
                const percentage = ratio.percentage;
                if (!deathPercentagesByYear[year]) {
                    deathPercentagesByYear[year] = [];
                }
                deathPercentagesByYear[year].push(percentage);
            });

            for (const year in percentagesByYear) {
                const ratioCanvas = document.getElementById(`ratioPieChart${year}`);
                if (!ratioCanvas) {
                    console.error(`Canvas with id 'ratioPieChart${year}' not found`);
                    continue;
                }

                const ctxRatio = ratioCanvas.getContext('2d');
                new Chart(ctxRatio, {
                    type: 'pie',
                    data: {
                        labels: ['끼임재해자 비율', '나머지'],
                        datasets: [{
                            label: `${year} 산업재해 대비 끼임재해자 비율`,
                            data: [percentagesByYear[year][0], 100 - percentagesByYear[year][0]],
                            backgroundColor: [
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(200, 50, 50, 0.2)'
                            ],
                            borderColor: [
                                'rgba(75, 192, 192, 1)',
                                'rgba(200, 50, 50, 1)'
                            ],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true
                    }
                });
            }

            for (const year in deathPercentagesByYear) {
                const deathCanvas = document.getElementById(`deathPieChart${year}`);
                if (!deathCanvas) {
                    console.error(`Canvas with id 'deathPieChart${year}' not found`);
                    continue;
                }

                const ctxDeath = deathCanvas.getContext('2d');
                new Chart(ctxDeath, {
                    type: 'pie',
                    data: {
                        labels: ['끼임재해 사망자 비율', '나머지'],
                        datasets: [{
                            label: `${year} 산업재해 대비 끼임재해 사망자 비율`,
                            data: [deathPercentagesByYear[year][0], 100 - deathPercentagesByYear[year][0]],
                            backgroundColor: [
                                'rgba(75, 192, 192, 0.2)',
                                'rgba(200, 50, 50, 0.2)'
                            ],
                            borderColor: [
                                'rgba(75, 192, 192, 1)',
                                'rgba(200, 50, 50, 1)'
                            ],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true
                    }
                });
            }
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }

    document.getElementById('showPieCharts').addEventListener('click', function () {
        document.getElementById('pieChartsContainer').style.display = 'block';
    });

    await fetchDataAndRenderChart('/ratio/chart', 'ratioChart', '끼임재해자', '산업재해자');
    await fetchDataAndRenderChart('/ratio/chart2', 'ratioChart2', '끼임재해 사망자', '산업재해 사망자');
    await fetchDataAndRenderPieCharts('/ratio/chart', '/ratio/chart2');
};
